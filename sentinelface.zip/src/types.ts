export interface Employee {
  id: string;
  name: string;
  role: string;
  department: string;
  email: string;
  baseSalary: number;
  joinedDate: string;
  status: 'Active' | 'On Leave' | 'Suspended';
  avatarUrl?: string; // Registered profile face image (Base64 or placeholder)
  biometricRegistered: boolean;
  biometricRegisteredAt?: string;
  biometricKey?: string; // Face pattern signature mock/uuid
}

export interface AttendanceLog {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeRole: string;
  employeeDepartment: string;
  date: string; // YYYY-MM-DD
  checkIn: string; // HH:MM:SS
  checkOut: string | null; // HH:MM:SS or null
  status: 'On-Time' | 'Late' | 'Absent' | 'Half-Day' | 'Overtime';
  biometricConfidence: number; // 0 - 100 percentage
  livenessPassed: boolean;
  antiSpoofNotes: string;
  capturedImageUrl?: string; // Captured snapshot during check-in/out
  verifiedBy: string; // "Face Biometrics V2" or "Manual (Admin)"
  notes?: string;
}

export interface BiometricVerifyResult {
  verified: boolean;
  faceDetected: boolean;
  confidenceScore: number;
  livenessPassed: boolean;
  antiSpoofingNotes: string;
  employee: Employee | null;
  faceMetrics?: {
    smile: string;
    gaze: string;
    lighting: string;
    maskDetected: boolean;
  };
}

export interface DepartmentSummary {
  name: string;
  totalEmployees: number;
  activeCount: number;
  attendanceRate: number; // 0 - 100
}

export interface AttendanceStats {
  presentCount: number;
  lateCount: number;
  onTimeCount: number;
  absentCount: number;
  onLeaveCount: number;
  averageAttendanceRate: number;
  dailyTrends: { date: string; present: number; late: number; absent: number }[];
}

export interface PayrollRecord {
  employeeId: string;
  name: string;
  role: string;
  department: string;
  baseSalary: number;
  daysPresent: number;
  daysLate: number;
  daysAbsent: number;
  deductions: number;
  bonus: number;
  netPayout: number;
  status: 'Draft' | 'Approved' | 'Paid';
  payoutDate?: string;
}

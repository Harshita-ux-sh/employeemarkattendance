import { useState } from 'react';
import { Users, Clock, AlertCircle, TrendingUp, Calendar, ArrowRight, UserCheck, ShieldCheck, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AttendanceLog, DepartmentSummary } from '../types';

interface DashboardOverviewProps {
  stats: {
    totalEmployees: number;
    activeEmployees: number;
    lateCount: number;
    presentCount: number;
    averageAttendanceRate: number;
    departmentSummaries: DepartmentSummary[];
    dailyTrends: { date: string; present: number; late: number; absent: number }[];
  } | null;
  logs: AttendanceLog[];
  onNavigateToScanner: () => void;
}

export default function DashboardOverview({ stats, logs, onNavigateToScanner }: DashboardOverviewProps) {
  const [selectedAuditLog, setSelectedAuditLog] = useState<AttendanceLog | null>(null);

  if (!stats) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-500">
        <Clock className="w-10 h-10 animate-spin text-slate-400 mb-2" />
        <p className="text-sm font-medium font-mono">Loading dashboard metrics...</p>
      </div>
    );
  }

  // Get today's details (mock or real dates matching logs)
  const todayDate = "2026-06-19";
  const logsToday = logs.filter(l => l.date === todayDate);
  const presentToday = logsToday.length;
  const lateToday = logsToday.filter(l => l.status === "Late").length;

  return (
    <div className="space-y-8">
      {/* Visual Metric Cards banner */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total employees contract roster */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm relative overflow-hidden group">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Total Workforce</span>
              <h4 className="text-3xl font-extrabold text-slate-950 font-sans tracking-tight">{stats.totalEmployees}</h4>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-800 border border-slate-200">
              <Users className="w-5.5 h-5.5 text-indigo-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-500 font-medium font-sans">
            <span className="text-indigo-600 font-bold flex items-center bg-indigo-50 px-1.5 py-0.5 rounded-md">100%</span>
            Active contracts in index
          </div>
          <div className="absolute right-0 bottom-0 w-24 h-24 bg-slate-50 rounded-full mix-blend-multiply opacity-50 translate-x-6 translate-y-6 pointer-events-none group-hover:scale-11 transition-transform" />
        </div>

        {/* Present Today tracker */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm relative overflow-hidden group">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Biometric Attendance Today</span>
              <h4 className="text-3xl font-extrabold text-slate-950 font-sans tracking-tight">{presentToday || stats.presentCount}</h4>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 border border-indigo-100 flex items-center justify-center">
              <UserCheck className="w-5.5 h-5.5" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-550 font-medium font-sans">
            <span className="text-indigo-600 font-bold bg-indigo-50 px-1.5 py-0.5 rounded-md">
              {Math.round(((presentToday || stats.presentCount) / stats.totalEmployees) * 100)}%
            </span>
            Active daily punch-in rate
          </div>
          <div className="absolute right-0 bottom-0 w-24 h-24 bg-indigo-50 rounded-full mix-blend-multiply opacity-30 translate-x-6 translate-y-6 pointer-events-none group-hover:scale-11 transition-transform" />
        </div>

        {/* Checked lates indicator */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm relative overflow-hidden group">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Late Flags Today</span>
              <h4 className="text-3xl font-extrabold text-slate-950 font-sans tracking-tight">{lateToday || stats.lateCount}</h4>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 border border-amber-100 flex items-center justify-center">
              <Clock className="w-5.5 h-5.5" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-550 font-medium font-sans">
            <span className="text-amber-600 font-bold bg-amber-50 px-1.5 py-0.5 rounded-md">
              {Math.round(((lateToday || stats.lateCount) / (presentToday || stats.presentCount || 1)) * 100)}%
            </span>
            Late index over check-ins
          </div>
          <div className="absolute right-0 bottom-0 w-24 h-24 bg-amber-50 rounded-full mix-blend-multiply opacity-30 translate-x-6 translate-y-6 pointer-events-none group-hover:scale-11 transition-transform" />
        </div>

        {/* Average corporate efficiency percentage */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm relative overflow-hidden group">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Avg Compliance Score</span>
              <h4 className="text-3xl font-extrabold text-slate-950 font-sans tracking-tight">{stats.averageAttendanceRate}%</h4>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-700 border border-slate-200">
              <TrendingUp className="w-5.5 h-5.5 text-indigo-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-550 font-medium font-sans">
            <span className="text-indigo-600 font-bold bg-indigo-50 px-1.5 py-0.5 rounded-md">Optimal</span>
            Within compliance SLA target
          </div>
          <div className="absolute right-0 bottom-0 w-24 h-24 bg-indigo-50/50 rounded-full mix-blend-multiply opacity-50 translate-x-6 translate-y-6 pointer-events-none group-hover:scale-11 transition-transform" />
        </div>
      </div>

      {/* Main Charts area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* SVG Daily Attendance Trend Line Chart */}
        <div className="lg:col-span-8 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="font-bold text-slate-900 text-lg">Biometric Active Trends</h3>
              <p className="text-xs text-slate-450 font-medium font-sans">Active daily check-in logs history (Previous 7 working days)</p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1.5 text-slate-500">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-600"></span> Present
              </span>
              <span className="flex items-center gap-1.5 text-slate-500">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span> Late
              </span>
              <span className="flex items-center gap-1.5 text-slate-500">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-300"></span> Absent
              </span>
            </div>
          </div>

          {/* Render clean and gorgeous custom SVG chart bars */}
          <div className="relative h-64 w-full flex items-end">
            <div className="absolute inset-y-0 left-0 right-0 flex flex-col justify-between pointer-events-none">
              <div className="border-t border-dashed border-slate-100 w-full h-0"></div>
              <div className="border-t border-dashed border-slate-100 w-full h-0"></div>
              <div className="border-t border-dashed border-slate-100 w-full h-0"></div>
              <div className="border-t border-dashed border-slate-100 w-full h-0"></div>
            </div>

            <div className="relative z-10 w-full h-full flex justify-around items-end pt-8">
              {stats.dailyTrends.map((trend, idx) => {
                const total = trend.present + trend.absent;
                const pctPresent = total > 0 ? (trend.present / total) * 100 : 0;
                const pctLate = total > 0 ? (trend.late / total) * 100 : 0;
                const pctAbsent = total > 0 ? (trend.absent / total) * 100 : 0;

                // Max scale values
                const maxVal = 6; // base total employees is 6
                const hPresent = Math.min(150, (trend.present / maxVal) * 130);
                const hLate = Math.min(150, (trend.late / maxVal) * 130);
                const hAbsent = Math.min(150, (trend.absent / maxVal) * 130);

                return (
                  <div key={idx} className="flex flex-col items-center group relative w-[12%]">
                    {/* Tooltip */}
                    <div className="absolute bottom-full mb-2 bg-slate-900 text-white text-[10px] p-2.5 rounded-xl shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20 min-w-[110px] space-y-1">
                      <p className="font-bold border-b border-slate-700 pb-1 mb-1">{trend.date}</p>
                      <p className="flex justify-between"><span>Present:</span> <strong className="text-indigo-400">{trend.present}</strong></p>
                      <p className="flex justify-between"><span>Lates:</span> <strong className="text-amber-400">{trend.late}</strong></p>
                      <p className="flex justify-between"><span>Absents:</span> <strong className="text-rose-400">{trend.absent}</strong></p>
                    </div>

                    {/* Stacked Graphic columns */}
                    <div className="w-10 flex flex-row items-end gap-1.5 justify-center mb-3">
                      {/* Column Present */}
                      <div 
                        style={{ height: `${Math.max(10, hPresent)}px` }}
                        className="w-2.5 bg-gradient-to-t from-indigo-600 to-indigo-500 rounded-full transition-all group-hover:brightness-95"
                      />
                      {/* Column Late */}
                      <div 
                        style={{ height: `${Math.max(10, hLate)}px` }}
                        className="w-2.5 bg-gradient-to-t from-amber-500 to-amber-400 rounded-full transition-all group-hover:brightness-95"
                      />
                      {/* Column Absent */}
                      <div 
                        style={{ height: `${Math.max(10, hAbsent)}px` }}
                        className="w-2.5 bg-slate-200 rounded-full transition-all group-hover:brightness-95"
                      />
                    </div>

                    <span className="text-[10px] font-bold text-slate-500 tracking-tight font-mono">{trend.date.replace(" June", "")} Jun</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Department Compliance indicators list */}
        <div className="lg:col-span-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <h3 className="font-bold text-slate-900 text-lg mb-1">Corporate Departments</h3>
          <p className="text-xs text-slate-400 mb-6 font-medium">Headcount & current attendance indexes</p>

          <div className="space-y-5">
            {stats.departmentSummaries.map((dept, index) => (
              <div key={index} className="space-y-1.5">
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-slate-800">{dept.name}</span>
                  <span className="text-slate-500 font-mono">
                    {dept.activeCount}/{dept.totalEmployees} Active • <strong className="text-indigo-600">{dept.attendanceRate}%</strong>
                  </span>
                </div>
                {/* Custom modern progress gauge */}
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden flex">
                  <div 
                    style={{ width: `${dept.attendanceRate}%` }} 
                    className="bg-indigo-600 h-full rounded-full"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Real-Time Live Logs Section with Visual Snapshots audit */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h3 className="font-bold text-slate-900 text-lg">Biometric Activity Logs Console</h3>
            <p className="text-xs text-slate-400 font-medium font-sans animate-pulse">● Real-time facial validation tracking live</p>
          </div>
          
          <button
            onClick={onNavigateToScanner}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-indigo-600/10 flex items-center gap-1 w-fit cursor-pointer"
          >
            Terminal View <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Logs Listing Grid/Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/50">
                <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Employee Reference</th>
                <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Authentication Timestamp</th>
                <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Verification Metrics</th>
                <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Liveness Confidence</th>
                <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Status Index</th>
                <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-center">Audit Profile</th>
              </tr>
            </thead>
            <tbody>
              {logs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400 text-sm">
                    No punch history logged on Terminal. Run a face biometric scan to start logs.
                  </td>
                </tr>
              ) : (
                logs.slice(0, 8).map((log) => (
                  <tr key={log.id} className="border-b border-slate-100 hover:bg-slate-50/40 transition-colors">
                    {/* ID + Photo thumb */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-slate-100 border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center relative group">
                          {log.capturedImageUrl ? (
                            <img src={log.capturedImageUrl} className="w-full h-full object-cover" />
                          ) : (
                            <span className="font-bold text-slate-600 text-xs font-mono">{log.employeeName.charAt(0)}</span>
                          )}
                        </div>
                        <div>
                          <h4 className="font-bold text-slate-900 text-sm">{log.employeeName}</h4>
                          <span className="text-[10px] text-slate-400 font-semibold uppercase">{log.employeeDepartment} • {log.employeeId}</span>
                        </div>
                      </div>
                    </td>

                    {/* Timestamp details */}
                    <td className="py-3.5 px-4">
                      <div className="text-slate-800 text-xs font-semibold">{log.date}</div>
                      <div className="text-[10px] text-slate-500 font-mono mt-0.5 font-bold">
                        Check-In: {log.checkIn} {log.checkOut ? `• Out: ${log.checkOut}` : ''}
                      </div>
                    </td>

                    {/* Verification engine tag */}
                    <td className="py-3.5 px-4">
                      <span className="text-xs font-medium text-slate-700 bg-slate-100 px-2.5 py-1 rounded-md">
                        {log.verifiedBy}
                      </span>
                    </td>

                    {/* Confidence Match index */}
                    <td className="py-3.5 px-4 font-mono text-xs font-bold text-slate-800">
                      <span className={`inline-flex items-center gap-1 ${
                        log.biometricConfidence >= 90 ? 'text-emerald-600' : 'text-amber-500'
                      }`}>
                        <ShieldCheck className="w-3.5 h-3.5" />
                        {log.biometricConfidence}% Match
                      </span>
                    </td>

                    {/* Status badge with appropriate coloring */}
                    <td className="py-3.5 px-4">
                      <span className={`inline-block px-2.5 py-0.5 text-[10px] font-bold rounded-full border tracking-wide uppercase ${
                        log.status === "On-Time"
                          ? "bg-emerald-50 text-emerald-700 border-emerald-100"
                          : log.status === "Late"
                          ? "bg-amber-50 text-amber-700 border-amber-100"
                          : log.status === "Overtime"
                          ? "bg-indigo-50 text-indigo-700 border-indigo-100"
                          : "bg-slate-50 text-slate-700 border-slate-200"
                      }`}>
                        {log.status}
                      </span>
                    </td>

                    {/* Visual capture inspect link */}
                    <td className="py-3.5 px-4 text-center">
                      <button
                        onClick={() => setSelectedAuditLog(log)}
                        className="px-3 py-1.5 hover:bg-slate-100 text-slate-700 hover:text-slate-900 rounded-lg text-xs font-bold transition-all border border-slate-150 inline-flex items-center gap-1 cursor-pointer"
                      >
                        Capture Audit
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Visual capture Audit inspect Overlay Modal */}
      <AnimatePresence>
        {selectedAuditLog && (
          <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl p-6 max-w-lg w-full border border-slate-200 shadow-xl overflow-hidden"
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h4 className="font-bold text-slate-950 text-lg">Biometric Audit Frame</h4>
                  <p className="text-xs text-slate-400 font-mono">Reference Entry ID: {selectedAuditLog.id}</p>
                </div>
                <button
                  onClick={() => setSelectedAuditLog(null)}
                  className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center transition-all cursor-pointer"
                >
                  &times;
                </button>
              </div>

              {/* Snapshot image container */}
              <div className="relative aspect-video rounded-2xl bg-slate-950 border border-slate-200 overflow-hidden flex items-center justify-center shadow-inner">
                {selectedAuditLog.capturedImageUrl ? (
                  <img src={selectedAuditLog.capturedImageUrl} className="w-full h-full object-cover scale-x-[-1]" />
                ) : (
                  <div className="text-slate-400 text-xs italic">Historical mock snapshot frame unmodified.</div>
                )}
                
                {/* Scanning HUD metrics */}
                <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-lg text-[9px] font-mono text-indigo-400 flex items-center gap-1.5 border border-white/10">
                  <ShieldCheck className="w-3 h-3 text-indigo-400" /> PASS: 3D FACE MATCHED
                </div>
                <div className="absolute top-3 right-3 bg-red-650 px-2.5 py-1 rounded-lg text-[9px] font-mono text-white flex items-center gap-1 font-bold">
                  REC FRAME
                </div>
                <div className="absolute bottom-3 left-3 bg-slate-900/85 px-2.5 py-1 rounded-lg text-[8px] font-mono text-slate-300">
                  REF EMBEDDING KEY MATCH: {selectedAuditLog.id.substring(0, 10)}
                </div>
              </div>

              {/* Sub-metrcs details */}
              <div className="mt-5 space-y-3">
                <div className="grid grid-cols-2 gap-4 text-xs font-semibold">
                  <div>
                    <span className="text-slate-400">Employee:</span>
                    <p className="text-slate-900">{selectedAuditLog.employeeName}</p>
                  </div>
                  <div>
                    <span className="text-slate-400">Compliance Code:</span>
                    <p className="text-slate-900 font-mono tracking-tight">{selectedAuditLog.employeeId}</p>
                  </div>
                  <div>
                    <span className="text-slate-400">Checked Logged:</span>
                    <p className="text-slate-900">{selectedAuditLog.date} @ {selectedAuditLog.checkIn}</p>
                  </div>
                  <div>
                    <span className="text-slate-400">Gateway Validation Method:</span>
                    <p className="text-slate-900 font-bold text-indigo-600 flex items-center gap-1">
                      <ShieldCheck className="w-4 h-4 inline" /> {selectedAuditLog.verifiedBy}
                    </p>
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <span className="text-slate-450 text-xs block mb-1 font-bold uppercase tracking-wider">Liveness / Anti-Spoof Diagnostics:</span>
                  <p className="text-xs text-slate-700 leading-normal font-sans italic">{selectedAuditLog.antiSpoofNotes}</p>
                </div>
              </div>

              <div className="mt-6 flex justify-end">
                <button
                  onClick={() => setSelectedAuditLog(null)}
                  className="px-5 py-2 hover:bg-slate-100 text-slate-700 hover:text-slate-900 font-bold rounded-xl text-xs transition-all border border-slate-200 cursor-pointer"
                >
                  Close Frame Audit
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

import { useState, useRef, useEffect } from 'react';
import { Camera, RefreshCw, CheckCircle, AlertTriangle, Eye, Shield, Smile, Sun, Award } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Employee, BiometricVerifyResult } from '../types';

interface BiometricScannerProps {
  employees: Employee[];
  onScanSuccess: () => void;
}

export default function BiometricScanner({ employees, onScanSuccess }: BiometricScannerProps) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string>("auto");
  const [scanMode, setScanMode] = useState<'checkin' | 'checkout'>('checkin');
  const [isScanning, setIsScanning] = useState(false);
  const [scanStatus, setScanStatus] = useState<string>("");
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [scanResult, setScanResult] = useState<BiometricVerifyResult | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    enableWebcam();
    return () => {
      stopWebcam();
    };
  }, []);

  const enableWebcam = async () => {
    try {
      setCameraError(null);
      const constraints = {
        video: { width: 640, height: 480, facingMode: 'user' }
      };
      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err: any) {
      console.error("Camera access failed:", err);
      setCameraError("Unable to access camera. Please confirm frame/camera permissions are enabled.");
    }
  };

  const stopWebcam = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const executeBiometricScan = async () => {
    if (!videoRef.current || !canvasRef.current) return;

    setIsScanning(true);
    setScanResult(null);

    // Dynamic scanning animation workflow
    const steps = [
      "Initializing high-definition video frame capture...",
      "Isolating biometric facial boundaries...",
      "Mapping local vector point matching algorithms...",
      "Running multi-modal liveness thermal verification...",
      "Transmitting to server neural biometric engine..."
    ];

    for (let i = 0; i < steps.length; i++) {
      setScanStatus(steps[i]);
      await new Promise(resolve => setTimeout(resolve, 450 + Math.random() * 200));
    }

    try {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;

      const context = canvas.getContext('2d');
      if (context) {
        // Capture snapshot from webcam frame
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        const photoBase64 = canvas.toDataURL('image/jpeg', 0.85);

        // API call to custom server
        const response = await fetch("/api/attendance/verify-biometric", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            photoBase64,
            employeeId: selectedEmployeeId,
            scanMode
          })
        });

        if (!response.ok) {
          throw new Error("HTTP connection to biometrics gateway timed out.");
        }

        const data: BiometricVerifyResult & { log?: any } = await response.json();
        setScanResult(data);

        if (data.verified) {
          onScanSuccess();
        }
      }
    } catch (err: any) {
      console.error(err);
      setScanStatus("Verification system encountered a gateway sync error.");
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Webcam Frame Control Area */}
      <div className="lg:col-span-7 bg-white p-6 rounded-3xl border border-slate-250 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h3 className="font-bold text-lg text-slate-900 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 animate-pulse"></span>
              Live Attendance Kiosk Gateway
            </h3>
            <p className="text-xs text-slate-400 font-medium">Secure 3D structured facial landmarks analysis</p>
          </div>
          
          <div className="flex bg-slate-100 p-1 rounded-xl w-fit self-end shrink-0 border border-slate-200">
            <button
              onClick={() => { setScanMode('checkin'); setScanResult(null); }}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold tracking-wide transition-all cursor-pointer ${
                scanMode === 'checkin'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Check-In Mode
            </button>
            <button
              onClick={() => { setScanMode('checkout'); setScanResult(null); }}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold tracking-wide transition-all cursor-pointer ${
                scanMode === 'checkout'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Check-Out Mode
            </button>
          </div>
        </div>

        {/* Video Wrapper */}
        <div className="relative bg-slate-950 rounded-2xl overflow-hidden aspect-video group shadow-xl border-4 border-white">
          {cameraError ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center text-white bg-slate-950">
              <AlertTriangle className="w-12 h-12 text-rose-500 mb-3 animate-bounce" />
              <p className="font-medium">{cameraError}</p>
              <button
                onClick={enableWebcam}
                className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Initialize Camera
              </button>
            </div>
          ) : (
            <>
              {/* Mock camera live feed badge overlay */}
              <div className="absolute top-4 left-4 flex items-center space-x-2 bg-black/50 backdrop-blur-md px-3 py-1 rounded-full border border-white/20 z-10">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                <span className="text-[10px] font-bold text-white uppercase tracking-widest">Live: Front Entrance</span>
              </div>

              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover scale-x-[-1]"
              />

              {/* Bio-scanner scanning meshes */}
              <div className="absolute inset-x-12 top-1/6 bottom-1/6 border-2 border-dashed border-indigo-400/40 rounded-full pointer-events-none flex items-center justify-center">
                <div className="w-36 h-36 border border-indigo-500/30 rounded-full flex items-center justify-center">
                  <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center"></div>
                </div>
              </div>

              {/* Moving scanning beam */}
              <AnimatePresence>
                {isScanning && (
                  <motion.div
                    initial={{ top: '15%' }}
                    animate={{ top: '85%' }}
                    exit={{ opacity: 0 }}
                    transition={{
                      repeat: Infinity,
                      repeatType: "reverse",
                      duration: 1.5,
                      ease: "easeInOut"
                    }}
                    className="absolute inset-x-8 h-0.5 bg-gradient-to-r from-transparent via-indigo-500 to-transparent shadow-[0_0_8px_rgba(99,102,241,0.8)] pointer-events-none z-10"
                  />
                )}
              </AnimatePresence>

              {/* Offline backup tag */}
              <div className="absolute bottom-3 left-3 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-lg flex items-center gap-1.5 border border-slate-700/50 z-10">
                <Shield className="w-3.5 h-3.5 text-indigo-400" />
                <span className="text-[10px] text-slate-300 font-mono tracking-tight">AES-256 BIOMETRIC ENCRYPTION</span>
              </div>
            </>
          )}
        </div>

        {/* Settings, targets and launcher */}
        <div className="mt-6 flex flex-col md:flex-row items-center gap-4">
          <div className="w-full md:w-auto flex-1">
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Administrative Override</label>
            <select
              value={selectedEmployeeId}
              onChange={(e) => { setSelectedEmployeeId(e.target.value); setScanResult(null); }}
              className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500"
            >
              <option value="auto">Auto-Identify (ML Facial Library Match)</option>
              {employees.filter(e => e.status === 'Active').map(e => (
                <option key={e.id} value={e.id}>
                  {e.name} ({e.id} – {e.department})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={executeBiometricScan}
            disabled={isScanning || !!cameraError}
            className={`w-full md:w-auto h-[42px] px-8 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white font-bold rounded-xl text-sm transition-all shadow-md shadow-indigo-600/10 flex items-center justify-center gap-2 mt-5 shrink-0 cursor-pointer`}
          >
            {isScanning ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" /> Verifying...
              </>
            ) : (
              <>
                <Camera className="w-4 h-4" /> Start Biometric Scan
              </>
            )}
          </button>
        </div>

        {/* Simulated status during run */}
        <AnimatePresence>
          {isScanning && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="mt-4 p-3 bg-indigo-50 border border-indigo-100 rounded-xl flex items-center gap-3 overflow-hidden"
            >
              <div className="w-2.5 h-2.5 rounded-full bg-indigo-600 animate-ping"></div>
              <p className="text-xs text-indigo-900 font-mono italic tracking-wide">{scanStatus}</p>
            </motion.div>
          )}
        </AnimatePresence>

        <canvas ref={canvasRef} className="hidden" />
      </div>

      {/* Verification Feedback Result Column */}
      <div className="lg:col-span-5 flex flex-col gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm shadow-slate-100/50 flex flex-col justify-between min-h-[380px]">
          <div>
            <h4 className="font-semibold text-slate-800 text-sm mb-4 uppercase tracking-widest text-slate-400">Live Scanners Log Output</h4>
            
            <AnimatePresence mode="wait">
              {!scanResult ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex flex-col items-center justify-center py-12 text-center"
                >
                  <div className="w-20 h-20 rounded-full bg-slate-50 flex items-center justify-center mb-4 text-slate-400 border border-slate-100">
                    <Eye className="w-8 h-8" />
                  </div>
                  <h5 className="font-semibold text-slate-700 text-sm">Awaiting Biometric Trigger</h5>
                  <p className="text-xs text-slate-400 mt-1 max-w-[240px] leading-relaxed">
                    Select check-in mode, position your face in the marker box, and trigger scanner capture.
                  </p>
                </motion.div>
              ) : (scanResult.verified && scanResult.employee) ? (
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  className="space-y-4"
                >
                  {/* Verified Employee Tag */}
                  <div className="p-4 bg-indigo-50 border border-indigo-150 rounded-2xl flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full border-2 border-white bg-slate-100 overflow-hidden shrink-0 shadow-sm flex items-center justify-center">
                      {scanResult.employee.avatarUrl ? (
                        <img src={scanResult.employee.avatarUrl} className="w-full h-full object-cover" />
                      ) : (
                        <span className="font-bold text-slate-700">{scanResult.employee.name.charAt(0)}</span>
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h5 className="font-bold text-slate-950 text-base">{scanResult.employee.name}</h5>
                        <CheckCircle className="w-4.5 h-4.5 text-indigo-600 fill-indigo-50" />
                      </div>
                      <p className="text-xs text-slate-600 font-medium">{scanResult.employee.role}</p>
                    </div>
                  </div>

                  {/* Biometric Scores info */}
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="bg-slate-50 p-3 rounded-xl border border-slate-150">
                      <span className="text-slate-400 block mb-0.5">Matching Confidence</span>
                      <strong className="text-slate-800 text-base font-bold font-mono text-indigo-600">
                        {scanResult.confidenceScore}%
                      </strong>
                    </div>
                    <div className="bg-slate-50 p-3 rounded-xl border border-slate-150">
                      <span className="text-slate-400 block mb-0.5">Liveness Verification</span>
                      <strong className="text-slate-800 text-base font-bold flex items-center gap-1 text-indigo-600">
                        <Shield className="w-4 h-4" /> Passed
                      </strong>
                    </div>
                  </div>

                  {/* Details indicators */}
                  <div className="bg-slate-50/50 p-4 rounded-xl border border-slate-150 space-y-2.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500 flex items-center gap-1">
                        <Smile className="w-3.5 h-3.5 text-slate-400" /> Expression
                      </span>
                      <span className="font-medium text-slate-800">{scanResult.faceMetrics?.smile || "Neutral"}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500 flex items-center gap-1">
                        <Eye className="w-3.5 h-3.5 text-slate-400" /> Gaze Alignment
                      </span>
                      <span className="font-medium text-slate-800">{scanResult.faceMetrics?.gaze || "Direct"}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500 flex items-center gap-1">
                        <Sun className="w-3.5 h-3.5 text-slate-400" /> Frame Lighting
                      </span>
                      <span className="font-medium text-slate-800">{scanResult.faceMetrics?.lighting || "Clear"}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500 flex items-center gap-1">
                        <Award className="w-3.5 h-3.5 text-slate-400" /> Spoof Shielding
                      </span>
                      <span className="font-medium text-slate-800 text-indigo-600 font-mono text-[10px]">VERIFIED OK</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 leading-tight bg-slate-50 p-3 rounded-xl border border-slate-150 font-mono">
                    <strong>Ref Security:</strong> {scanResult.antiSpoofingNotes}
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  className="space-y-4"
                >
                  <div className="p-5 bg-rose-50 border border-rose-100 rounded-2xl flex flex-col items-center justify-center text-center">
                    <AlertTriangle className="w-10 h-10 text-rose-500 mb-3" />
                    <h5 className="font-bold text-rose-900 text-sm">Biometric Rejection</h5>
                    <p className="text-xs text-rose-700 mt-1 max-w-[280px]">
                      Facial scan match failed or is low confidence. Please clear frame objects, remove hats/masks, ensure proper lighting, and scan again.
                    </p>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-150 text-xs">
                    <span className="text-slate-400 block mb-1">Gate Anti-Spoof Report:</span>
                    <p className="font-mono text-slate-700 leading-tight">{scanResult.antiSpoofingNotes}</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="border-t border-slate-150 pt-4 mt-4 flex items-center justify-between text-xs text-slate-400">
            <span className="flex items-center gap-1">
              <Shield className="w-3.5 h-3.5 text-indigo-500" /> Terminal: Front-Desk-Kiosk-1
            </span>
            <span className="font-mono">v3.12-AES-6</span>
          </div>
        </div>

        {/* Biometric best practices */}
        <div className="bg-indigo-50/40 p-4 rounded-2xl border border-slate-200 text-xs">
          <h5 className="font-bold text-indigo-950 mb-1">Operational Checklist:</h5>
          <ul className="list-disc pl-4 space-y-1 text-slate-600 leading-normal">
            <li>Position head directly in front of camera lens</li>
            <li>Stand with neutral facial expression</li>
            <li>Avoid heavy backlight or obscuring face parts</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

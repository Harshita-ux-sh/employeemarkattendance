import React, { useState, useRef, useEffect } from 'react';
import { Search, Plus, Trash2, ShieldAlert, Check, X, Camera, RefreshCw, UserCheck, Mail, DollarSign, Briefcase, HeartCrack } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Employee } from '../types';

interface EmployeeDirectoryProps {
  employees: Employee[];
  onEmployeeUpdate: () => void;
}

export default function EmployeeDirectory({ employees, onEmployeeUpdate }: EmployeeDirectoryProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [deptFilter, setDeptFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [showAddModal, setShowAddModal] = useState(false);

  // New Employee state
  const [newName, setNewName] = useState("");
  const [newRole, setNewRole] = useState("");
  const [newDept, setNewDept] = useState("Engineering");
  const [newEmail, setNewEmail] = useState("");
  const [newSalary, setNewSalary] = useState("4500");
  const [capturedAvatar, setCapturedAvatar] = useState<string | null>(null);

  // Registration Webcam variables
  const [camStream, setCamStream] = useState<MediaStream | null>(null);
  const [caming, setCaming] = useState(false);
  const [camError, setCamError] = useState<string | null>(null);
  const regVideoRef = useRef<HTMLVideoElement>(null);
  const regCanvasRef = useRef<HTMLCanvasElement>(null);

  const [registering, setRegistering] = useState(false);

  const startRegistrationWebcam = async () => {
    try {
      setCamError(null);
      setCaming(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 320, height: 240, facingMode: 'user' }
      });
      setCamStream(stream);
      if (regVideoRef.current) {
        regVideoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error(err);
      setCamError("Camera not accessible.");
    }
  };

  const stopRegistrationWebcam = () => {
    if (camStream) {
      camStream.getTracks().forEach(track => track.stop());
      setCamStream(null);
    }
    setCaming(false);
  };

  const captureRegistrationSnap = () => {
    if (!regVideoRef.current || !regCanvasRef.current) return;
    const video = regVideoRef.current;
    const canvas = regCanvasRef.current;
    canvas.width = 300;
    canvas.height = 225;

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const base64 = canvas.toDataURL('image/jpeg', 0.85);
      setCapturedAvatar(base64);
      stopRegistrationWebcam();
    }
  };

  const saveEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newRole || !newEmail || !newSalary) {
      alert("Please complete all registration parameters.");
      return;
    }

    setRegistering(true);

    try {
      const response = await fetch("/api/employees", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newName,
          role: newRole,
          department: newDept,
          email: newEmail,
          baseSalary: Number(newSalary),
          avatarUrl: capturedAvatar
        })
      });

      if (!response.ok) {
        throw new Error("Roster registration pipeline failed.");
      }

      // Refresh list, close modal, clear values
      onEmployeeUpdate();
      setShowAddModal(false);
      setNewName("");
      setNewRole("");
      setNewEmail("");
      setNewSalary("4500");
      setCapturedAvatar(null);
    } catch (err: any) {
      console.error(err);
      alert("Failed to submit profile register workflow.");
    } finally {
      setRegistering(false);
    }
  };

  const deleteEmployee = async (empId: string) => {
    if (!confirm("Confirming employee deletion will erase all historic logs associated with them. Proceed?")) return;

    try {
      const response = await fetch(`/api/employees/${empId}`, {
        method: "DELETE"
      });
      if (response.ok) {
        onEmployeeUpdate();
      } else {
        alert("Failed to delete employee profile.");
      }
    } catch (err) {
      console.error(err);
      alert("Failed to remove profile roster.");
    }
  };

  // Perform client filter
  const filteredEmployees = employees.filter(emp => {
    const sTerm = searchTerm.toLowerCase();
    const matchSearch = emp.name.toLowerCase().includes(sTerm) || emp.id.toLowerCase().includes(sTerm);
    const matchDept = deptFilter === "All" || emp.department === deptFilter;
    const matchStatus = statusFilter === "All" || emp.status === statusFilter;
    return matchSearch && matchDept && matchStatus;
  });

  return (
    <div className="space-y-6">
      {/* Directory Search & Register button */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full sm:w-auto flex-1">
          {/* Search text panel */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search Employee, ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white border border-slate-250 pl-10 pr-4 py-2 text-sm rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/50 text-slate-800"
            />
          </div>

          {/* Department Filter Selector */}
          <select
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
            className="bg-white border border-slate-250 px-4 py-2 text-sm rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/50 text-slate-700"
          >
            <option value="All">All Departments</option>
            <option value="Engineering">Engineering</option>
            <option value="Marketing">Marketing</option>
            <option value="HR & People">HR & People</option>
            <option value="Finance">Finance</option>
            <option value="Operations">Operations</option>
          </select>

          {/* Status Select Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-white border border-slate-250 px-4 py-2 text-sm rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/50 text-slate-700"
          >
            <option value="All">All Statuses</option>
            <option value="Active">Active</option>
            <option value="On Leave">On Leave</option>
            <option value="Suspended">Suspended</option>
          </select>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="w-full sm:w-auto px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition-all shadow-md shadow-indigo-600/10 flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Register New Profile
        </button>
      </div>

      {/* Corporate Employees directory grid layout */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredEmployees.length === 0 ? (
          <div className="col-span-full bg-white py-16 text-center text-slate-450 text-sm border border-slate-200 rounded-3xl">
            No employees found matching filter definitions.
          </div>
        ) : (
          filteredEmployees.map((emp) => (
            <div
              key={emp.id}
              className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                {/* Visual Header */}
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full border border-slate-200 bg-slate-50 overflow-hidden flex items-center justify-center relative shadow-inner">
                      {emp.avatarUrl ? (
                        <img src={emp.avatarUrl} className="w-full h-full object-cover" />
                      ) : (
                        <span className="font-bold text-slate-700 text-base">{emp.name.charAt(0)}</span>
                      )}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-950 text-sm leading-tight">{emp.name}</h4>
                      <p className="text-xs text-slate-400 font-medium mt-0.5">{emp.role}</p>
                    </div>
                  </div>

                  <span className={`px-2.5 py-0.5 text-[10px] font-bold rounded-full border tracking-wide uppercase ${
                    emp.status === "Active"
                      ? "bg-indigo-50 text-indigo-700 border-indigo-100"
                      : emp.status === "On Leave"
                      ? "bg-amber-50 text-amber-700 border-amber-100"
                      : "bg-rose-50 text-rose-700 border-rose-100"
                  }`}>
                    {emp.status}
                  </span>
                </div>

                {/* Body Details */}
                <div className="space-y-2 border-t border-slate-205 pt-4 text-xs text-slate-600">
                  <p className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-slate-400 font-bold" />
                    <span className="truncate">{emp.email}</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <Briefcase className="w-3.5 h-3.5 text-slate-400" />
                    <span>{emp.department} • Ref: {emp.id}</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <DollarSign className="w-3.5 h-3.5 text-slate-400" />
                    <span>Monthly Payroll Scheme: <strong>${emp.baseSalary.toLocaleString()}/mo</strong></span>
                  </p>
                </div>
              </div>

              {/* Bottom Registration & Actions */}
              <div className="mt-5 pt-4 border-t border-slate-205 flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-md flex items-center gap-1">
                  <UserCheck className="w-3.5 h-3.5 text-indigo-600" /> BIOMETRICS SECURED
                </span>

                <button
                  onClick={() => deleteEmployee(emp.id)}
                  title="Remove employee profile"
                  className="p-2 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-xl transition-all cursor-pointer border border-transparent hover:border-rose-100"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Registration Roster Dialog modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl p-6 max-w-2xl w-full border border-slate-200 shadow-xl overflow-hidden max-h-[90vh] overflow-y-auto"
            >
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h3 className="font-bold text-slate-950 text-xl font-sans">Register Employee Profile</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Initialize employee contract registry with face biometric mappings</p>
                </div>
                <button
                  onClick={() => { stopRegistrationWebcam(); setShowAddModal(false); }}
                  className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center transition-all cursor-pointer"
                >
                  &times;
                </button>
              </div>

              <form onSubmit={saveEmployee} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                  {/* Personal Params */}
                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Full Legal Name</label>
                      <input
                        type="text"
                        required
                        value={newName}
                        onChange={(e) => setNewName(e.target.value)}
                        placeholder="e.g. Abigail Finch"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 text-slate-800"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Designation Role</label>
                      <input
                        type="text"
                        required
                        value={newRole}
                        onChange={(e) => setNewRole(e.target.value)}
                        placeholder="e.g. Senior Software Engineer"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 text-slate-800"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1">Department</label>
                        <select
                          value={newDept}
                          onChange={(e) => setNewDept(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 text-slate-800"
                        >
                          <option value="Engineering">Engineering</option>
                          <option value="Marketing">Marketing</option>
                          <option value="HR & People">HR & People</option>
                          <option value="Finance">Finance</option>
                          <option value="Operations">Operations</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-600 mb-1">Monthly Base Salary ($)</label>
                        <input
                          type="number"
                          required
                          value={newSalary}
                          onChange={(e) => setNewSalary(e.target.value)}
                          placeholder="Salary"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 text-slate-800"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">Worker Corporate Email Address</label>
                      <input
                        type="email"
                        required
                        value={newEmail}
                        onChange={(e) => setNewEmail(e.target.value)}
                        placeholder="e.g. name@enterprise.io"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 text-slate-800"
                      />
                    </div>
                  </div>

                  {/* Facial captures camera stream container */}
                  <div className="space-y-4">
                    <label className="block text-xs font-semibold text-slate-600">3D Face Matrix Key Mapping (Camera)</label>
                    <div className="relative border-2 border-dashed border-slate-250 rounded-2xl aspect-[4/3] bg-slate-55 overflow-hidden flex items-center justify-center">
                      {capturedAvatar ? (
                        <div className="relative w-full h-full group">
                          <img src={capturedAvatar} className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                            <button
                              type="button"
                              onClick={() => { setCapturedAvatar(null); startRegistrationWebcam(); }}
                              className="px-4 py-2 bg-white text-slate-900 rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
                            >
                              <RefreshCw className="w-3.5 h-3.5" /> Retake snapshot
                            </button>
                          </div>
                        </div>
                      ) : caming ? (
                        <div className="relative w-full h-full">
                          <video
                             ref={regVideoRef}
                             autoPlay
                             playsInline
                             className="w-full h-full object-cover scale-x-[-1]"
                          />
                          <button
                            type="button"
                            onClick={captureRegistrationSnap}
                            className="absolute bottom-4 left-1/2 -translate-x-1/2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-md z-10 flex items-center gap-1 cursor-pointer"
                          >
                            <Camera className="w-3.5 h-3.5" /> Take Snapshot
                          </button>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center p-6 text-center">
                          <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center border border-indigo-100 mb-3">
                            <Camera className="w-5 h-5" />
                          </div>
                          <button
                            type="button"
                            onClick={startRegistrationWebcam}
                            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
                          >
                            Activate Registry Camera
                          </button>
                          <p className="text-[10px] text-slate-400 mt-2 max-w-[180px]">
                            Connect webcam to capture initial reference face ID parameters.
                          </p>
                        </div>
                      )}
                    </div>
                    {camError && <p className="text-[10px] text-rose-500 text-center font-bold">{camError}</p>}
                    <canvas ref={regCanvasRef} className="hidden" />
                  </div>
                </div>

                {/* Submit button controls */}
                <div className="border-t border-slate-200 pt-6 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => { stopRegistrationWebcam(); setShowAddModal(false); }}
                    className="px-5 py-2.5 hover:bg-slate-50 text-slate-600 hover:text-slate-800 font-bold rounded-xl text-xs transition-all border border-slate-200 cursor-pointer"
                  >
                    Cancel Registration
                  </button>
                  <button
                    type="submit"
                    disabled={registering}
                    className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition-all shadow-md cursor-pointer"
                  >
                    {registering ? (
                      <span className="flex items-center gap-1.5">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Mappings database...
                      </span>
                    ) : "Save Roster Employee"}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

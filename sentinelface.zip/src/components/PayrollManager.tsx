import { useState } from 'react';
import { DollarSign, ShieldAlert, BadgeInfo, CheckCircle, RefreshCw, Send, Printer, User, Wallet } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PayrollRecord } from '../types';

interface PayrollManagerProps {
  payrollData: {
    records: PayrollRecord[];
    history: { id: string; payoutDate: string; totalPaid: number; employeesCount: number }[];
  } | null;
  onPayrollRelease: () => void;
}

export default function PayrollManager({ payrollData, onPayrollRelease }: PayrollManagerProps) {
  const [selectedSlip, setSelectedSlip] = useState<PayrollRecord | null>(null);
  const [releasing, setReleasing] = useState(false);

  if (!payrollData) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-500">
        <RefreshCw className="w-10 h-10 animate-spin text-slate-400 mb-2" />
        <p className="text-sm font-medium font-mono">Compiling monthly compensations...</p>
      </div>
    );
  }

  const runAllPayouts = async () => {
    if (!confirm("Are you sure you want to release bank disbursements and sign direct deposits for all active workers? This will generate payroll history records.")) return;

    setReleasing(true);
    try {
      const response = await fetch("/api/payroll/payout", {
        method: "POST"
      });

      if (response.ok) {
        onPayrollRelease();
        alert("Payroll disbursements locked and direct deposits signed successfully!");
      } else {
        alert("Failed to release payroll batches.");
      }
    } catch (err) {
      console.error(err);
      alert("Error dispatching direct bank transfers.");
    } finally {
      setReleasing(false);
    }
  };

  const activeRecords = payrollData.records;
  const payoutHistory = payrollData.history;

  const totalMonthlyPayrollDraft = activeRecords.reduce((sum, rec) => sum + rec.netPayout, 0);
  const isReleasedThisMonth = activeRecords.some(r => r.status === "Paid");

  return (
    <div className="space-y-8">
      {/* Financial Overview stats strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">Total Payout Draft</span>
            <h4 className="text-3xl font-extrabold text-slate-950 font-sans tracking-tight">${totalMonthlyPayrollDraft.toLocaleString()}</h4>
            <span className="text-[10px] text-slate-400 block mt-1.5 font-medium font-mono">CYCLE: JUNE 2026</span>
          </div>
          <div className="w-12 h-12 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-center text-slate-800">
            <DollarSign className="w-5.5 h-5.5 text-indigo-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">Disbursement Status</span>
            {isReleasedThisMonth ? (
              <h4 className="text-2xl font-extrabold text-indigo-600 flex items-center gap-1.5 mt-1">
                <CheckCircle className="w-5.5 h-5.5 text-indigo-600" /> Disbursed
              </h4>
            ) : (
              <h4 className="text-2xl font-extrabold text-amber-500 flex items-center gap-1.5 mt-1">
                <BadgeInfo className="w-5.5 h-5.5 text-amber-550" /> Awaiting Release
              </h4>
            )}
            <span className="text-[10px] text-slate-400 block mt-2 font-medium">Standard ACH batch process</span>
          </div>
          <div className="w-12 h-12 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-center text-slate-800">
            <Wallet className="w-5.5 h-5.5 text-indigo-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 tracking-wider uppercase block mb-1">Release Actions</span>
            <button
              onClick={runAllPayouts}
              disabled={isReleasedThisMonth || releasing}
              className="mt-2.5 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-100 disabled:text-slate-400 font-bold text-white rounded-xl text-xs tracking-wide transition-all shadow-md shadow-indigo-600/10 cursor-pointer"
            >
              {releasing ? (
                <span className="flex items-center gap-1">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Transmitting Transfers...
                </span>
              ) : isReleasedThisMonth ? "JUNE BATCH PAID" : "Approve & Release June Payouts"}
            </button>
          </div>
        </div>
      </div>

      {/* Main Payroll grid table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6">
        <h3 className="font-bold text-slate-900 text-lg mb-1">Automatic Payroll Matrix</h3>
        <p className="text-xs text-slate-450 mb-6 font-medium">Auto-compiled financial calculations matching biometric active logs</p>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/50">
                <th className="py-3 px-4 text-xs font-bold text-slate-450 uppercase tracking-wider">Employee</th>
                <th className="py-3 px-4 text-xs font-bold text-slate-450 uppercase tracking-wider">Contracted Base</th>
                <th className="py-3 px-4 text-xs font-bold text-slate-450 uppercase tracking-wider">Present Flags</th>
                <th className="py-3 px-4 text-xs font-bold text-slate-450 uppercase tracking-wider">Deductions (Lates/Abs)</th>
                <th className="py-3 px-4 text-xs font-bold text-slate-450 uppercase tracking-wider">Bonuses (Overtime)</th>
                <th className="py-3 px-4 text-xs font-bold text-slate-450 uppercase tracking-wider">Net Monthly Payout</th>
                <th className="py-3 px-4 text-xs font-bold text-slate-450 uppercase tracking-wider">Disbursement State</th>
                <th className="py-3 px-4 text-xs font-bold text-slate-450 uppercase tracking-wider text-center">Payslip</th>
              </tr>
            </thead>
            <tbody>
              {activeRecords.map((rec) => (
                <tr key={rec.employeeId} className="border-b border-slate-200 hover:bg-slate-50/40 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-slate-900 text-sm">
                    {rec.name}
                    <span className="block text-[10px] text-slate-400 font-semibold uppercase">{rec.role}</span>
                  </td>
                  <td className="py-3.5 px-4 font-mono text-xs font-bold text-slate-700">${rec.baseSalary.toLocaleString()}/mo</td>
                  <td className="py-3.5 px-4 text-xs font-medium text-slate-800">
                    <span className="text-indigo-650 font-bold">{rec.daysPresent} Yes</span> • <span className="text-amber-500">{rec.daysLate} Late</span> • <span className="text-rose-500">{rec.daysAbsent} Abs</span>
                  </td>
                  <td className="py-3.5 px-4 font-mono text-xs text-rose-600 font-bold">
                    {rec.deductions > 0 ? `-$${rec.deductions.toLocaleString()}` : "$0"}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-xs text-indigo-600 font-bold">
                    {rec.bonus > 0 ? `+$${rec.bonus.toLocaleString()}` : "$0"}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-sm font-extrabold text-slate-950">${rec.netPayout.toLocaleString()}</td>
                  <td className="py-3.5 px-4">
                    <span className={`inline-block px-2.5 py-0.5 text-[9px] font-bold rounded-full border tracking-wide uppercase ${
                      rec.status === "Paid"
                        ? "bg-indigo-50 text-indigo-700 border-indigo-100"
                        : "bg-slate-50 text-slate-600 border-slate-200"
                    }`}>
                      {rec.status === "Paid" ? "Cleared" : "Draft (Pending)"}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <button
                      onClick={() => setSelectedSlip(rec)}
                      className="px-3 py-1.5 hover:bg-slate-100 text-slate-700 hover:text-slate-900 rounded-lg text-xs font-bold border border-slate-200 cursor-pointer"
                    >
                      Audit Slip
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Historical Payroll payouts archive for HR tracking */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6">
        <h3 className="font-bold text-slate-900 text-lg mb-1">Corporate Disbursements History</h3>
        <p className="text-xs text-slate-400 mb-6 font-medium">Record of all certified funds releases</p>

        <div className="space-y-3">
          {payoutHistory.length === 0 ? (
            <p className="text-xs text-slate-400 italic">No historical payouts archived.</p>
          ) : (
            payoutHistory.map((hist) => (
              <div key={hist.id} className="p-4 bg-slate-50/50 border border-slate-200 rounded-2xl flex items-center justify-between text-xs font-semibold">
                <div>
                  <span className="text-slate-400">Batch Code:</span>
                  <span className="text-slate-800 ml-1.5 font-mono">{hist.id}</span>
                  <span className="text-slate-300 mx-2">|</span>
                  <span className="text-slate-400">Released On:</span>
                  <span className="text-slate-800 ml-1.5">{hist.payoutDate}</span>
                </div>
                <div>
                  <span className="text-slate-550 mr-4 font-normal">{hist.employeesCount} Workers Contracted</span>
                  <span className="text-sm font-extrabold text-indigo-850 bg-indigo-50 border border-indigo-150 px-3.5 py-1 rounded-xl">
                    Total Disbursed: ${hist.totalPaid.toLocaleString()}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Payslip Auditor inspect modal */}
      <AnimatePresence>
        {selectedSlip && (
          <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl p-8 max-w-lg w-full border border-slate-200 shadow-xl overflow-hidden font-sans"
            >
              {/* Slip Header */}
              <div className="border-b-2 border-dashed border-slate-200 pb-5 mb-5 flex justify-between items-start">
                <div>
                  <h4 className="font-bold text-slate-950 text-lg uppercase tracking-wide">Corporate Payment Slip</h4>
                  <p className="text-xs text-slate-400">BATCH SYSTEM ARCHIVE • CONFIDENTIAL</p>
                </div>
                <button
                  onClick={() => setSelectedSlip(null)}
                  className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center transition-all cursor-pointer"
                >
                  &times;
                </button>
              </div>

              {/* Personal specs */}
              <div className="grid grid-cols-2 gap-4 text-xs font-semibold mb-6">
                <div>
                  <span className="text-slate-400">Recipient Name</span>
                  <p className="text-slate-900 text-sm mt-0.5">{selectedSlip.name}</p>
                </div>
                <div>
                  <span className="text-slate-400">Employee ID Ref</span>
                  <p className="text-slate-900 font-mono text-sm mt-0.5">{selectedSlip.employeeId}</p>
                </div>
                <div>
                  <span className="text-slate-400">Department</span>
                  <p className="text-slate-900 text-sm mt-0.5">{selectedSlip.department}</p>
                </div>
                <div>
                  <span className="text-slate-400">Pay Period</span>
                  <p className="text-slate-900 text-sm mt-0.5">June 1st, 2026 - June 30th, 2026</p>
                </div>
              </div>

              {/* Payment Math table ledger */}
              <div className="space-y-3.5 border-t border-b border-slate-200 py-6 text-xs select-none">
                <div className="flex justify-between items-center text-slate-600">
                  <span>Contracted Base Salary</span>
                  <span className="font-bold font-mono text-slate-800">${selectedSlip.baseSalary.toLocaleString()}.00</span>
                </div>
                
                {selectedSlip.bonus > 0 && (
                  <div className="flex justify-between items-center text-indigo-600 font-bold">
                    <span>Overtime Bonuses (Biometric verified)</span>
                    <span className="font-bold font-mono">+${selectedSlip.bonus.toLocaleString()}.00</span>
                  </div>
                )}

                {selectedSlip.deductions > 0 && (
                  <div className="flex justify-between items-center text-rose-600">
                    <span>Deductions / Penalties (Late / Absences logs)</span>
                    <span className="font-bold font-mono">-${selectedSlip.deductions.toLocaleString()}.00</span>
                  </div>
                )}

                <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono pl-3 border-l-2 border-slate-250 pt-1">
                  <span>Calculations: {selectedSlip.daysPresent} presents • {selectedSlip.daysLate} lates • {selectedSlip.daysAbsent} absences</span>
                </div>
              </div>

              {/* Total final Net */}
              <div className="flex justify-between items-center mt-6 p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Net Final Payout</span>
                  <h5 className="text-2xl font-black text-slate-950 font-sans tracking-tight">${selectedSlip.netPayout.toLocaleString()}.00</h5>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 font-mono block">ACH DIRECT ROUTED</span>
                  <span className="text-[9px] text-indigo-650 font-extrabold uppercase font-mono bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-100 mt-1 inline-block">
                    {selectedSlip.status === "Paid" ? "CLEARED" : "AUTHENTICATED"}
                  </span>
                </div>
              </div>

              {/* Signature checks */}
              <div className="mt-6 flex justify-between items-center text-[10px] text-slate-400 font-mono border-t border-slate-200 pt-5">
                <span>SYSTEM AUTHORIZATION BLOCK: APPROVED</span>
                <span>SHA-256 SIGNED DIRECT</span>
              </div>

              <div className="mt-8 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedSlip(null)}
                  className="px-5 py-2 hover:bg-slate-100 text-slate-700 hover:text-slate-900 font-bold rounded-xl text-xs transition-all border border-slate-200 cursor-pointer"
                >
                  Close Slip
                </button>
                <button
                  type="button"
                  onClick={() => { window.print(); }}
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition-all shadow-md flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" /> Print Payslip
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { Camera, LayoutDashboard, FolderKanban, Banknote, ShieldAlert, BadgeInfo, FileDown, RefreshCw, Landmark, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Modular Components importations
import DashboardOverview from './components/DashboardOverview';
import BiometricScanner from './components/BiometricScanner';
import EmployeeDirectory from './components/EmployeeDirectory';
import PayrollManager from './components/PayrollManager';
import ReportsHub from './components/ReportsHub';

import { Employee, AttendanceLog, PayrollRecord } from './types';

type ActiveTab = 'overview' | 'kiosk' | 'directory' | 'payroll' | 'reports';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [logs, setLogs] = useState<AttendanceLog[]>([]);
  const [payrollData, setPayrollData] = useState<{
    records: PayrollRecord[];
    history: { id: string; payoutDate: string; totalPaid: number; employeesCount: number }[];
  } | null>(null);
  const [dashboardStats, setDashboardStats] = useState<any | null>(null);
  
  const [syncing, setSyncing] = useState(false);

  // Synchronize state from Express server backend APIs
  const synchronizeDatabase = async () => {
    setSyncing(true);
    try {
      const [empRes, logRes, payRes, statRes] = await Promise.all([
        fetch("/api/employees"),
        fetch("/api/attendance/logs"),
        fetch("/api/payroll/summary"),
        fetch("/api/stats/dashboard")
      ]);

      if (empRes.ok && logRes.ok && payRes.ok && statRes.ok) {
        const [empData, logData, payData, statData] = await Promise.all([
          empRes.json(),
          logRes.json(),
          payRes.json(),
          statRes.json()
        ]);

        setEmployees(empData);
        setLogs(logData);
        setPayrollData(payData);
        setDashboardStats(statData);
      } else {
        console.error("API responses encountered a non-ok endpoint response.");
      }
    } catch (err) {
      console.error("Failed to synchronize relational API trees:", err);
    } finally {
      setSyncing(false);
    }
  };

  useEffect(() => {
    synchronizeDatabase();
  }, []);

  return (
    <div className="min-h-screen bg-[#F3F4F6] text-slate-800 antialiased font-sans select-none flex flex-col">
      
      {/* Top Professional Portal branding Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            
            {/* Logo details matching Design HTML */}
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                <div className="w-4 h-4 bg-white rounded-sm rotate-45"></div>
              </div>
              <span className="text-xl font-bold tracking-tight text-slate-900">Sentinel<span className="text-indigo-600">Face</span></span>
            </div>

            {/* Sync control and metadata indicators including Sarah Jenkins Profile mockup */}
            <div className="flex items-center gap-6">
              <button
                onClick={synchronizeDatabase}
                disabled={syncing}
                title="Synchronize real-time logs and calculations"
                className="p-1.5 hover:bg-slate-50 text-slate-400 hover:text-indigo-600 rounded-xl transition-all border border-slate-100 inline-flex items-center justify-center cursor-pointer"
              >
                <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin text-indigo-600' : ''}`} />
              </button>

              <div className="hidden md:flex flex-col items-end text-right">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wilder">HR Manager</span>
                <span className="text-xs font-semibold text-slate-800">Sarah Jenkins</span>
              </div>
              
              <div className="w-9 h-9 rounded-full bg-slate-200 border border-white shadow-xs flex items-center justify-center text-slate-600 font-bold font-sans text-xs select-none">
                SJ
              </div>
            </div>

          </div>
        </div>
      </header>

      {/* Main navigation & Workspace viewport */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full flex flex-col gap-6">
        
        {/* Tab Selection controller bar */}
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 border-b border-slate-100 pb-2">
          
          {/* Subheader info text */}
          <div>
            <h2 className="text-slate-950 font-extrabold text-2xl tracking-tight leading-none uppercase">
              {activeTab === 'overview' && 'Workforce Command'}
              {activeTab === 'kiosk' && 'Kiosk Punch Terminal'}
              {activeTab === 'directory' && 'Corporate Directory'}
              {activeTab === 'payroll' && 'Payroll calculations Ledger'}
              {activeTab === 'reports' && 'HR Reports Hub'}
            </h2>
            <p className="text-xs text-slate-400 font-medium font-sans mt-1">
              {activeTab === 'overview' && 'Real-time corporate metrics, weekly log outputs and productivity indices.'}
              {activeTab === 'kiosk' && 'Position face box coordinates to file checked daily entries.'}
              {activeTab === 'directory' && 'Roster profiling list, contract base salaries, status and registration.'}
              {activeTab === 'payroll' && 'Automated compliance penalizations, overtime bonuses and disbursement triggers.'}
              {activeTab === 'reports' && 'Executive package downloads. Compiles print-ready PDFs and Excel files.'}
            </p>
          </div>

          <div className="flex overflow-x-auto bg-slate-200/55 p-1 rounded-2xl w-full sm:w-auto shrink-0 select-none no-scrollbar border border-slate-250">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-4.5 py-2.5 rounded-xl text-xs font-bold transition-all tracking-wide flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeTab === 'overview'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" /> Dashboard
            </button>
            <button
              onClick={() => setActiveTab('kiosk')}
              className={`px-4.5 py-2.5 rounded-xl text-xs font-bold transition-all tracking-wide flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeTab === 'kiosk'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Camera className="w-4 h-4" /> Kiosk Terminal
            </button>
            <button
              onClick={() => setActiveTab('directory')}
              className={`px-4.5 py-2.5 rounded-xl text-xs font-bold transition-all tracking-wide flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeTab === 'directory'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FolderKanban className="w-4 h-4" /> Employees
            </button>
            <button
              onClick={() => setActiveTab('payroll')}
              className={`px-4.5 py-2.5 rounded-xl text-xs font-bold transition-all tracking-wide flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeTab === 'payroll'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Banknote className="w-4 h-4" /> Payroll Scheme
            </button>
            <button
              onClick={() => setActiveTab('reports')}
              className={`px-4.5 py-2.5 rounded-xl text-xs font-bold transition-all tracking-wide flex items-center gap-1.5 shrink-0 cursor-pointer ${
                activeTab === 'reports'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileDown className="w-4 h-4" /> Reports
            </button>
          </div>
        </div>

        {/* Viewport content switcher */}
        <div className="flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.22, ease: "easeOut" }}
            >
              {activeTab === 'overview' && (
                <DashboardOverview
                  stats={dashboardStats}
                  logs={logs}
                  onNavigateToScanner={() => setActiveTab('kiosk')}
                />
              )}

              {activeTab === 'kiosk' && (
                <BiometricScanner
                  employees={employees}
                  onScanSuccess={synchronizeDatabase}
                />
              )}

              {activeTab === 'directory' && (
                <EmployeeDirectory
                  employees={employees}
                  onEmployeeUpdate={synchronizeDatabase}
                />
              )}

              {activeTab === 'payroll' && (
                <PayrollManager
                  payrollData={payrollData}
                  onPayrollRelease={synchronizeDatabase}
                />
              )}

              {activeTab === 'reports' && (
                <ReportsHub
                  employees={employees}
                  logs={logs}
                  payroll={payrollData ? payrollData.records : []}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </div>

      </div>

      {/* Sentinel-styled corporate footer */}
      <footer className="bg-white border-t border-slate-200 py-4 px-8 mt-auto shrink-0 shadow-xs flex justify-between items-center text-[10px] text-slate-450 font-bold uppercase tracking-wider font-sans select-none">
        <div className="flex items-center space-x-4">
          <span className="text-slate-400">Sentinel v2.4.1</span>
          <div className="h-3 w-px bg-slate-300"></div>
          <span className="text-slate-400">FastAPI Node: HQ-North</span>
        </div>
        <div className="flex space-x-6 text-slate-500 font-mono">
          <span>Encryption: AES-256</span>
          <span>Biometric Hash: SHA-3</span>
        </div>
      </footer>

    </div>
  );
}
